package com.example.projetocarrosmayaramota01212163;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoCarrosMayaraMota01212163Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoCarrosMayaraMota01212163Application.class, args);
	}

}
