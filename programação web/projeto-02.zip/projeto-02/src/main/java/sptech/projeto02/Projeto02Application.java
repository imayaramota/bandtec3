package sptech.projeto02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto02Application {

	public static void main(String[] args) {
		SpringApplication.run(Projeto02Application.class, args);
	}

}
