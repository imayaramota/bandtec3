public class App {
    public static void main(String[] args) {
        System.out.println("Selection Sort");
        Ordenacao.selectionSort();
        System.out.println("Bubble Sort");
        Ordenacao.bubbleSort();
    }
}
