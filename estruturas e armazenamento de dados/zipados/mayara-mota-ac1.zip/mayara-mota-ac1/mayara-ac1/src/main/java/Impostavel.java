public interface Impostavel {
    public Double getImposto();
}
