public class Teste {

    // Testar Classe ListaEstatica
    public static void main(String[] args) {

    }
}
