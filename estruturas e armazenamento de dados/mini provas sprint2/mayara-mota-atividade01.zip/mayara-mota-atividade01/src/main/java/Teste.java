import java.util.ListIterator;
import java.util.Scanner;

public class Teste {
    public static void main(String[] args) {
        Integer opcao = 0;
        Scanner leitor = new Scanner(System.in);
        Scanner leitor2 = new Scanner(System.in);
        Scanner leitorNl = new Scanner(System.in);
        System.out.println("Loja de Eletrônicos MM!");

        ListaObj<Eletronico> listaEletronicos = new ListaObj<>(10);

        do{
            System.out.println("Escolha uma opção: (digite 1, 2 ou 3)");
            System.out.println("1 - Cadastrar um Eletrônico");
            System.out.println("2 - Exibir todos Eletrônicos Cadastrados");
            System.out.println("3 - Sair do Sistema");
            opcao = leitor.nextInt();

            switch (opcao){
                case 1:
                    System.out.println("Digite o identificador desse eletrônicos:");
                    int id = leitor.nextInt();

                    System.out.println("Digite o nome:");
                    String nome = leitorNl.nextLine();

                    System.out.println("Digite a categoria:");
                    String categoria = leitorNl.nextLine();

                    System.out.println("Digite o valor:");
                    Double valor = leitor.nextDouble();

                    System.out.println("Digite a quantidade disponivel em estoque em estoque:");
                    int qtdEstoque = leitor.nextInt();

                    listaEletronicos.adiciona(new Eletronico(id,nome,categoria,valor,qtdEstoque));

                    System.out.println("Produto adicionado coom sucesso!");
                    break;
                case 2:
                    System.out.println("");
                    System.out.printf("%-6s %-14s %-10s %10s %-7s \n", "CÓDIGO", "PRODUTO", "CATEGORIA", "VALOR", "ESTOQUE");
                    for (int i = 0; i < listaEletronicos.getTamanho(); i++){
                        Eletronico e = listaEletronicos.getElemento(i);
                        System.out.printf("%06d %-14s %-10s %10.2f %7d \n", e.getId(),e.getNome(),e.getCategoria(),e.getValor(),e.getQuantidadeEmEstoque());
                    }
                    System.out.printf("");
                    break;
                case 3:
                    System.out.println("Obrigada por utilizar nosso sistema :)");
                    break;
                default:
                    System.out.println("Opção digitada inválida!!");
                    break;
            }
        }while (opcao != 3);
    }
}
